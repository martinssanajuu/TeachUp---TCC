<!-- <?php get_users($con);?> -->
<br><a href="?pagina=inicio">Solicitações de amizade<?php echo return_total_solicitation($con);?></a>
<?php solicitacoes($con);?>
<?php ?>